<?php
/**
 * Plugin Name:       Agent block: testimonial
 * Description:       Test fixture package for the x-companion block library.
 * Version:           2.0.0
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * License:           GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', static function () { register_block_type( __DIR__ . '/testimonial' ); } );
